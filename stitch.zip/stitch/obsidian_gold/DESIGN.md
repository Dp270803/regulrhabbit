# Design System Strategy: Obsidian Precision

## 1. Overview & Creative North Star
The Creative North Star for this design system is **"Obsidian Precision."** This system moves away from the cluttered, "gamified" aesthetic of typical fitness apps and instead adopts the language of high-end horology and boutique editorial design. We are not just building a tracker; we are building a digital vault for one’s personal progress.

The interface breaks the traditional "app grid" by utilizing intentional asymmetry, oversized display typography, and a hyper-focused use of color. By leveraging deep charcoal tones and high-contrast accents, we create an environment where the user’s data feels like a premium asset. The goal is to make every habit completed feel like a luxury achievement.

## 2. Colors
This system relies on a monochromatic base to allow functional colors to vibrate with purpose. 

*   **The "No-Line" Rule:** Designers are strictly prohibited from using 1px solid borders to define sections. Layout boundaries must be established through background color shifts. For example, a card component using `surface_container_low` should sit on a `surface` background. The shift in tone is the boundary.
*   **Surface Hierarchy & Nesting:** Use the surface-container tiers to create physical depth. 
    *   **Base:** `surface` (#131313)
    *   **Nested Elements:** Use `surface_container_lowest` (#0e0e0e) to create "wells" of content, or `surface_container_high` (#2a2a2a) for elevated interaction points.
*   **The "Glass & Gradient" Rule:** To provide "soul" to the minimalist palette, floating overlays (like bottom sheets or modals) should use a semi-transparent `surface_variant` with a 20px backdrop blur.
*   **Signature Textures:** For high-impact CTAs, use a subtle linear gradient from `primary` (#e9c349) to `on_primary_container` (#977800) to give the gold a metallic, tactile finish.

## 3. Typography
The typography is the primary driver of the brand's authoritative voice. We pair the structural weight of **Manrope** for data and headlines with the clinical clarity of **Inter** for utility.

*   **Display & Headlines (Manrope):** These should be treated as hero elements. Use `display-lg` for daily streaks and `headline-lg` for category titles. The high contrast between the bold weights and the dark background creates a sense of "prestige."
*   **Body & Labels (Inter):** These are the workhorses. Use `body-md` for habit descriptions. `label-sm` should be used sparingly for meta-data, always in all-caps with a 0.05em letter spacing to maintain a technical, high-end feel.
*   **Hierarchy as Identity:** Large-scale numbers (XP, Reps, Days) should always be in `display` scales to emphasize the user's "Identity-based" growth.

## 4. Elevation & Depth
In this system, depth is a result of light and material, not structural lines.

*   **The Layering Principle:** Stacking is the new bordering. Place a `surface_container_highest` element inside a `surface_container_low` container to define focus.
*   **Ambient Shadows:** For elements that truly "float" (like a primary action button), use a diffused shadow: `box-shadow: 0 20px 40px rgba(19, 19, 19, 0.4)`. The shadow should never be pure black; it should feel like a soft occlusion of light.
*   **The "Ghost Border" Fallback:** If a container requires definition for accessibility, use the "Ghost Border": `outline_variant` (#444748) at 15% opacity. It should be felt, not seen.
*   **Glassmorphism:** Use `surface_bright` with a 60% opacity and a heavy blur for navigation bars to allow content to bleed through, softening the transition between sections.

## 5. Components

### The Dot-Track Visualization (Identity System)
The core of the habit system. Use a horizontal grid of 2x2dp dots. 
- **Inactive:** `surface_container_highest`. 
- **In-Progress:** `primary` (Gold).
- **Completed:** `secondary_container` (Neon Green).
- **Visual logic:** Dots should have a `DEFAULT` (0.25rem) corner radius.

### Buttons
- **Primary:** `primary` (#e9c349) background with `on_primary` (#3c2f00) text. Bold, 0.25rem radius.
- **Secondary (Ghost):** No background. `outline_variant` at 20% opacity. Text in `on_surface`.
- **States:** On hover/active, the `primary` button should transition to a subtle gradient to mimic a physical press into light.

### Cards & Lists
- **Rule:** Absolute prohibition of divider lines. 
- **Implementation:** Separate list items using 12px of vertical white space. If items must be grouped, use a `surface_container_low` background for the entire group, utilizing the "No-Line" rule for the outer edge.

### Checkboxes & Radio Buttons
- These should not look like standard OS components. 
- **Unchecked:** A 20px square with a `surface_container_highest` fill.
- **Checked:** A flash of `secondary_container` (#2ff801) that scales from the center, creating a "pop" of completion.

### Input Fields
- **Style:** Underline only, using the `outline` (#8e9192) token at 30% opacity. On focus, the underline morphs into a 2px `primary` (Gold) bar.
- **Typography:** Placeholder text should use `body-md` in `on_tertiary_container`.

## 6. Do's and Don'ts

### Do
*   **Embrace the Void:** Use generous padding (32px+) around major data points to let the typography breathe.
*   **Use Functional Color:** Only use `secondary_container` (Green) when a task is 100% finished. Use `primary` (Gold) to signify the "value" of the effort.
*   **Nesting:** Use `surface_container_lowest` for the deepest parts of the UI, like an empty state "well."

### Don't
*   **No Pure Black:** Avoid #000000 for backgrounds. Use `surface` (#131313) to maintain depth and avoid OLED smearing.
*   **No Standard Shadows:** Never use high-opacity, small-radius shadows. They look "cheap" and break the Obsidian Precision aesthetic.
*   **No Icons without Context:** Icons should always be accompanied by a `label-sm` or be so universal that they require no explanation. In this system, typography is the icon.